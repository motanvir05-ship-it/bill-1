var express = require('express');
var crypto = require('crypto');
var fs = require('fs');
var path = require('path');
var router = express.Router();

var DATA_DIR = path.join(__dirname, '..', 'data');
var USERS_FILE = path.join(DATA_DIR, 'users.json');
var PLANS_FILE = path.join(DATA_DIR, 'plans.json');
var ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
var TICKETS_FILE = path.join(DATA_DIR, 'support.json');
var SECRET = process.env.SESSION_SECRET || 'primecloud-change-this-secret';
var OWNER_EMAIL = (process.env.OWNER_EMAIL || 'owner@primecloud.fun').toLowerCase();
var OWNER_PASSWORD = process.env.OWNER_PASSWORD || 'PrimeCloud@12345';
var ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@primecloud.fun').toLowerCase();
var ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'PrimeCloudAdmin@12345';
var QR_URL = '/img/payment-qr.png';

var SEED_PLANS = [];
[
  ['mc-budget-2','MC Budget 2GB','MC Budget','₹20','2GB RAM • 50% CPU • 10GB Disk','Budget processor'],
  ['mc-budget-4','MC Budget 4GB','MC Budget','₹40','4GB RAM • 100% CPU • 20GB Disk','Budget processor'],
  ['mc-budget-6','MC Budget 6GB','MC Budget','₹80','6GB RAM • 125% CPU • 25GB Disk','Budget processor'],
  ['mc-budget-8','MC Budget 8GB','MC Budget','₹100','8GB RAM • 200% CPU • 30GB Disk','Budget processor'],
  ['mc-budget-12','MC Budget 12GB','MC Budget','₹200','12GB RAM • 300% CPU • 60GB Disk','Budget processor'],
  ['mc-budget-16','MC Budget 16GB','MC Budget','₹300','16GB RAM • 400% CPU • 70GB Disk','Budget processor'],
  ['mc-premium-2','MC Premium 2GB','MC Premium','₹20','2GB RAM • 50% CPU • 10GB Disk','AMD processor'],
  ['mc-premium-4','MC Premium 4GB','MC Premium','₹40','4GB RAM • 100% CPU • 20GB Disk','AMD processor'],
  ['mc-premium-6','MC Premium 6GB','MC Premium','₹80','6GB RAM • 125% CPU • 25GB Disk','AMD processor'],
  ['mc-premium-8','MC Premium 8GB','MC Premium','₹100','8GB RAM • 200% CPU • 30GB Disk','AMD processor'],
  ['mc-premium-12','MC Premium 12GB','MC Premium','₹200','12GB RAM • 300% CPU • 60GB Disk','AMD processor'],
  ['mc-premium-16','MC Premium 16GB','MC Premium','₹300','16GB RAM • 400% CPU • 70GB Disk','AMD processor']
].forEach(function(x){ SEED_PLANS.push({id:x[0],name:x[1],category:x[2],price:x[3],specs:x[4],processor:x[5],stock:true}); });

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, {recursive:true});
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '[]');
if (!fs.existsSync(PLANS_FILE)) fs.writeFileSync(PLANS_FILE, JSON.stringify(SEED_PLANS, null, 2));
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]');
if (!fs.existsSync(TICKETS_FILE)) fs.writeFileSync(TICKETS_FILE, '[]');

function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch(e) { return fallback; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data,null,2)); }
function hashPassword(password, salt) { salt=salt||crypto.randomBytes(16).toString('hex'); return {salt:salt,hash:crypto.pbkdf2Sync(password,salt,120000,64,'sha512').toString('hex')}; }
function verifyPassword(password,user) { if(!user || !user.salt || !user.hash) return false; var h=crypto.pbkdf2Sync(password,user.salt,120000,64,'sha512').toString('hex'); return crypto.timingSafeEqual(Buffer.from(h),Buffer.from(user.hash)); }
function sign(payload) { var body=Buffer.from(JSON.stringify(payload)).toString('base64url'); var sig=crypto.createHmac('sha256',SECRET).update(body).digest('base64url'); return body+'.'+sig; }
function currentUser(req) {
  var raw=req.headers.cookie && (req.headers.cookie.match(/(?:^|; )pc_session=([^;]+)/)||[])[1]; if(!raw) return null;
  var parts=raw.split('.'); if(parts.length!==2) return null;
  var expected=crypto.createHmac('sha256',SECRET).update(parts[0]).digest('base64url'); if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(parts[1]))) return null;
  try { var p=JSON.parse(Buffer.from(parts[0],'base64url').toString()); if(!p.exp || p.exp<Date.now()) return null; return p; } catch(e){return null;}
}
function setSession(res,user) { res.setHeader('Set-Cookie','pc_session='+sign({email:user.email,role:user.role,exp:Date.now()+7*24*60*60*1000})+'; Path=/; HttpOnly; SameSite=Lax'); }
function render(res,view,extra){ res.render(view,Object.assign({qrUrl:QR_URL},extra||{})); }
function requireLogin(req,res,next){ var u=currentUser(req); if(!u) return res.redirect('/login?error=Please%20login%20first'); req.user=u; next(); }
function requireStaff(req,res,next){ var u=currentUser(req); if(!u || (u.role!=='owner' && u.role!=='admin')) return res.redirect('/login?error=Admin%20or%20owner%20login%20required'); req.user=u; next(); }
function requireOwner(req,res,next){ var u=currentUser(req); if(!u || u.role!=='owner') return res.redirect('/admin?error=Owner%20access%20required'); req.user=u; next(); }
function slug(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
function getPlans(category){ var all=readJson(PLANS_FILE,[]); return category ? all.filter(function(p){return p.category===category;}) : all; }

router.use(function(req,res,next){ res.locals.user=currentUser(req); res.locals.qrUrl=QR_URL; res.locals.error=req.query.error||null; next(); });
router.get('/', function(req,res){ render(res,'index',{page:'Home',plans:getPlans('MC Budget').concat(getPlans('MC Premium'))}); });
router.get('/about',function(req,res){render(res,'about',{page:'About'});});
router.get('/contact',function(req,res){res.redirect('/support');});
router.get('/plans',function(req,res){render(res,'plans',{plans:readJson(PLANS_FILE,[])});});
router.get('/minecraft',function(req,res){render(res,'plans',{plans:getPlans('MC Budget').concat(getPlans('MC Premium')),title:'Minecraft Hosting'});});
router.get('/minecraft_free',function(req,res){res.redirect('/minecraft');});
router.get('/minecraft_intel',function(req,res){res.redirect('/minecraft');});
router.get('/minecraft_amd',function(req,res){res.redirect('/minecraft');});
router.get('/vps_free',function(req,res){render(res,'plans',{plans:[],title:'VPS Free Plans'});});
router.get('/vps_intel',function(req,res){render(res,'plans',{plans:getPlans('VPS Intel'),title:'Intel VPS'});});
router.get('/vps_amd',function(req,res){render(res,'plans',{plans:getPlans('VPS AMD').concat(getPlans('VPS Ryzen')),title:'AMD / Ryzen VPS'});});
router.get('/rdp',function(req,res){render(res,'plans',{plans:getPlans('RDP').concat(getPlans('Windows RDP')),title:'RDP Hosting'});});
router.get('/bot',function(req,res){render(res,'plans',{plans:getPlans('BOT').concat(getPlans('Bot Hosting')),title:'BOT Hosting'});});
router.get('/website',function(req,res){render(res,'plans',{plans:getPlans('Website').concat(getPlans('WEB')),title:'WEB Hosting'});});
router.get('/service',function(req,res){render(res,'service',{title:'Services',description:'PrimeCloud hosting services',plans:readJson(PLANS_FILE,[])});});

router.get('/support',function(req,res){render(res,'support',{success:req.query.success||null,error:req.query.error||null});});
router.post('/support',function(req,res){
  var name=String(req.body.name||'').trim(), email=String(req.body.email||'').trim().toLowerCase(), subject=String(req.body.subject||'').trim(), message=String(req.body.message||'').trim();
  if(!name||!email||!subject||!message) return res.redirect('/support?error=Please%20fill%20all%20fields');
  var tickets=readJson(TICKETS_FILE,[]); tickets.push({id:'TKT-'+Date.now().toString(36).toUpperCase(),name:name,email:email,subject:subject,message:message,createdAt:new Date().toISOString(),status:'open'}); writeJson(TICKETS_FILE,tickets);
  res.redirect('/support?success=Support%20request%20submitted%20successfully');
});
router.post('/support/:id/close',requireStaff,function(req,res){var t=readJson(TICKETS_FILE,[]);var x=t.find(function(a){return a.id===req.params.id;});if(x){x.status='closed';x.closedBy=req.user.email;writeJson(TICKETS_FILE,t);}res.redirect('/admin');});

router.get('/register',function(req,res){render(res,'register',{error:req.query.error||null});});
router.post('/register',function(req,res){
  var name=String(req.body.name||'').trim(),email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');
  if(!name||!email||password.length<6) return res.redirect('/register?error=Use%20a%20valid%20name%2C%20email%20and%206%2B%20character%20password');
  if(email===OWNER_EMAIL||email===ADMIN_EMAIL) return res.redirect('/register?error=This%20email%20is%20reserved');
  var users=readJson(USERS_FILE,[]); if(users.some(function(u){return u.email===email;})) return res.redirect('/register?error=Account%20already%20exists');
  var hp=hashPassword(password); users.push({id:'USR-'+Date.now().toString(36),name:name,email:email,salt:hp.salt,hash:hp.hash,role:'user',createdAt:new Date().toISOString()}); writeJson(USERS_FILE,users); setSession(res,{email:email,role:'user'}); res.redirect('/account');
});
router.get('/login',function(req,res){render(res,'login',{error:req.query.error||null});});
router.post('/login',function(req,res){
  var email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');
  if(email===OWNER_EMAIL && password===OWNER_PASSWORD){setSession(res,{email:email,role:'owner'});return res.redirect('/admin');}
  if(email===ADMIN_EMAIL && password===ADMIN_PASSWORD){setSession(res,{email:email,role:'admin'});return res.redirect('/admin');}
  var user=readJson(USERS_FILE,[]).find(function(u){return u.email===email;});
  if(!user||!verifyPassword(password,user)) return res.redirect('/login?error=Invalid%20email%20or%20password');
  setSession(res,{email:user.email,role:user.role||'user'}); res.redirect(user.role==='owner'||user.role==='admin'?'/admin':'/account');
});
router.get('/logout',function(req,res){res.setHeader('Set-Cookie','pc_session=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax');res.redirect('/');});
router.get('/account',requireLogin,function(req,res){render(res,'account',{user:req.user,orders:readJson(ORDERS_FILE,[]).filter(function(o){return o.email===req.user.email;})});});

router.post('/order',requireLogin,function(req,res){
  var planId=String(req.body.planId||''),plans=readJson(PLANS_FILE,[]),p=plans.find(function(x){return x.id===planId;});
  if(!p) return res.redirect('/plans?error=Plan%20not%20found');
  if(!p.stock) return res.redirect('/plans?error=This%20plan%20is%20out%20of%20stock');
  var orders=readJson(ORDERS_FILE,[]), id='PC-'+Date.now().toString(36).toUpperCase();
  orders.push({id:id,email:req.user.email,planId:p.id,planName:p.name,category:p.category,price:p.price,specs:p.specs,processor:p.processor||'',status:'pending',createdAt:new Date().toISOString()}); writeJson(ORDERS_FILE,orders); res.redirect('/order-success?id='+encodeURIComponent(id));
});
router.get('/order-success',requireLogin,function(req,res){var o=readJson(ORDERS_FILE,[]).find(function(x){return x.id===req.query.id&&x.email===req.user.email;}); if(!o) return res.redirect('/plans'); render(res,'order_success',{order:o});});

router.get('/admin',requireStaff,function(req,res){render(res,'admin',{plans:readJson(PLANS_FILE,[]),users:readJson(USERS_FILE,[]),orders:readJson(ORDERS_FILE,[]),tickets:readJson(TICKETS_FILE,[]),isOwner:req.user.role==='owner',adminEmail:ADMIN_EMAIL,ownerEmail:OWNER_EMAIL,error:req.query.error||null});});
router.post('/admin/plans/add',requireStaff,function(req,res){var name=String(req.body.name||'').trim(),category=String(req.body.category||'').trim(),price=String(req.body.price||'').trim(),specs=String(req.body.specs||'').trim(),processor=String(req.body.processor||'').trim();if(!name||!category||!price)return res.redirect('/admin?error=Name%2C%20category%20and%20price%20are%20required');var p=readJson(PLANS_FILE,[]);p.push({id:slug(name)+'-'+Date.now().toString(36),name:name,category:category,price:price,specs:specs,processor:processor,stock:true});writeJson(PLANS_FILE,p);res.redirect('/admin');});
router.post('/admin/plans/:id/toggle',requireStaff,function(req,res){var p=readJson(PLANS_FILE,[]),x=p.find(function(a){return a.id===req.params.id;});if(x){x.stock=!x.stock;writeJson(PLANS_FILE,p);}res.redirect('/admin');});
router.post('/admin/plans/:id/delete',requireStaff,function(req,res){writeJson(PLANS_FILE,readJson(PLANS_FILE,[]).filter(function(a){return a.id!==req.params.id;}));res.redirect('/admin');});
router.post('/admin/orders/:id/status',requireStaff,function(req,res){var allowed=['pending','paid','processing','completed','cancelled'];var status=String(req.body.status||'pending');if(allowed.indexOf(status)<0)status='pending';var o=readJson(ORDERS_FILE,[]),x=o.find(function(a){return a.id===req.params.id;});if(x){x.status=status;x.updatedAt=new Date().toISOString();x.updatedBy=req.user.email;writeJson(ORDERS_FILE,o);}res.redirect('/admin');});
router.post('/admin/users/:id/delete',requireOwner,function(req,res){writeJson(USERS_FILE,readJson(USERS_FILE,[]).filter(function(u){return u.id!==req.params.id;}));res.redirect('/admin');});
router.post('/admin/users/create',requireOwner,function(req,res){var name=String(req.body.name||'').trim(),email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||''),role=req.body.role==='admin'?'admin':'user';if(!name||!email||password.length<6)return res.redirect('/admin?error=Name%2C%20email%20and%206%2B%20character%20password%20required');var u=readJson(USERS_FILE,[]);if(email===OWNER_EMAIL||email===ADMIN_EMAIL||u.some(function(x){return x.email===email;}))return res.redirect('/admin?error=Email%20already%20reserved%20or%20used');var hp=hashPassword(password);u.push({id:'USR-'+Date.now().toString(36),name:name,email:email,salt:hp.salt,hash:hp.hash,role:role,createdAt:new Date().toISOString()});writeJson(USERS_FILE,u);res.redirect('/admin');});
router.post('/admin/users/:id/role',requireOwner,function(req,res){var role=req.body.role==='admin'?'admin':'user',u=readJson(USERS_FILE,[]),x=u.find(function(a){return a.id===req.params.id;});if(x){x.role=role;writeJson(USERS_FILE,u);}res.redirect('/admin');});

module.exports=router;
